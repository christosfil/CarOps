import java.util.ArrayList;

public class Employe {

	private String username;
	private String password;
	private String phoneNum;
	private String email;
	private ArrayList<Employe> employeeList;

	public Employe() {
		// TODO - implement Employe.Employe
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public boolean login(int username, int password) {
		// TODO - implement Employe.login
		throw new UnsupportedOperationException();
	}

	public void addEmployee() {
		// TODO - implement Employe.addEmployee
		throw new UnsupportedOperationException();
	}

}