public class TechnicianEngineer extends Engineer {

	private int itemsList;
	private int timeList;

	public int usedItemsList() {
		// TODO - implement TechnicianEngineer.usedItemsList
		throw new UnsupportedOperationException();
	}

	public double usedItemsCost() {
		// TODO - implement TechnicianEngineer.usedItemsCost
		throw new UnsupportedOperationException();
	}

	public void updateTime() {
		// TODO - implement TechnicianEngineer.updateTime
		throw new UnsupportedOperationException();
	}

	public int checkSupply() {
		// TODO - implement TechnicianEngineer.checkSupply
		throw new UnsupportedOperationException();
	}

	public void order() {
		// TODO - implement TechnicianEngineer.order
		throw new UnsupportedOperationException();
	}

	public void addRepair() {
		// TODO - implement TechnicianEngineer.addRepair
		throw new UnsupportedOperationException();
	}

}