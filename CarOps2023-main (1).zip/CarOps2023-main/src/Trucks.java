public class Trucks extends Vehicle {

	private double payload;

}