import java.util.ArrayList;

public class CustomerSupport extends Employe {

	private ArrayList<Appointment> reservList;
	private ArrayList<Customer> customerList;
	private double paymentsList;

	public void reservation() {
		// TODO - implement CustomerSupport.reservation
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param name
	 * @param surname
	 * @param phoneNumber
	 * @param address
	 * @param email
	 */
	public void newCustomer(String name, String surname, int phoneNumber, String address, String email) {
		// TODO - implement CustomerSupport.newCustomer
		throw new UnsupportedOperationException();
	}

	public void addCustomer() {
		// TODO - implement CustomerSupport.addCustomer
		throw new UnsupportedOperationException();
	}

	public boolean searchCustomer() {
		// TODO - implement CustomerSupport.searchCustomer
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param reservList
	 */
	public void availableAppointments(ArrayList<Appointment> reservList) {
		// TODO - implement CustomerSupport.availableAppointments
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param reservList
	 */
	public void addAppointment(ArrayList<Appointment> reservList) {
		// TODO - implement CustomerSupport.addAppointment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param paymentsList
	 */
	public void paymentAdd(int paymentsList) {
		// TODO - implement CustomerSupport.paymentAdd
		throw new UnsupportedOperationException();
	}

}