public class Motorcycle extends Vehicle {

	private int cubism;

}