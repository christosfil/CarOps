import java.util.ArrayList;

public class EntryEngineer extends Engineer {

	private ArrayList<Vehicle> carsList;

	public void carEntry() {
		// TODO - implement EntryEngineer.carEntry
		throw new UnsupportedOperationException();
	}

	public String cosTimetEst() {
		// TODO - implement EntryEngineer.cosTimetEst
		throw new UnsupportedOperationException();
	}

	public void addRepair() {
		// TODO - implement EntryEngineer.addRepair
		throw new UnsupportedOperationException();
	}

	public boolean searchVehicle() {
		// TODO - implement EntryEngineer.searchVehicle
		throw new UnsupportedOperationException();
	}

}