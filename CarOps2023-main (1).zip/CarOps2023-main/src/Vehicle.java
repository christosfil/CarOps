import java.util.ArrayList;

public class Vehicle {

	private String licenseTemp;
	private String brand;
	private String model;
	private int year;
	private int vehicleId;
	private ArrayList<Vehicle> vehicleList;

	public Vehicle() {
		// TODO - implement Vehicle.Vehicle
		throw new UnsupportedOperationException();
	}

}