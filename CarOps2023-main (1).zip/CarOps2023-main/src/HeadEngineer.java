import java.util.ArrayList;

public class HeadEngineer extends Engineer {

	private ArrayList<Vehicle> repairtList;

}