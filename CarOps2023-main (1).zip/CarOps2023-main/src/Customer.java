public class Customer {

	private String name;
	private String surname;
	private int phoneNumber;
	private String address;
	private String email;
	private int customerId;

	/**
	 * 
	 * @param name
	 * @param surname
	 * @param phoneNumber
	 * @param address
	 * @param email
	 */
	public Customer Customer(String name, String surname, int phoneNumber, String address, String email) {
		// TODO - implement Customer.Customer
		throw new UnsupportedOperationException();
	}

}